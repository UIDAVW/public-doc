//
//  LYHistoryCameraViewController.h
//  LYCloudDemo
//
//  Created by QuinnQiu on 16/1/14.
//  Copyright © 2016年 QuinnQiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYHistoryCameraViewController : UIViewController

@end
