//
//  LYHistoryModel.h
//  LYDemo
//
//  Created by 羚羊云 on 16/1/13.
//  Copyright © 2016年 lingyangyun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYHistoryModel : NSObject

/**
 *  录像起始时间
 */

@property(nonatomic,strong)NSNumber *from;

/**
 *  录像结束时间
 */

@property(nonatomic,strong)NSNumber *to;



@end
