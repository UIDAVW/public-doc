//
//  ViewController.h
//  LYSDKDemo
//
//  Created by QuinnQiu on 16/5/31.
//  Copyright © 2016年 QuinnQiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

