//
//  LYCloudWatchViewController.h
//  LingyangAPI
//
//  Created by QuinnQiu on 16/3/15.
//  Copyright © 2016年 QuinnQiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYCloudWatchViewController : UIViewController

@end
