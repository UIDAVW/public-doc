#pragma once
class SDKDemoControl
{
public:
	SDKDemoControl(void);
	~SDKDemoControl(void);

public:
	int startService();

	void stopService();

	void exit();

private:

};

