#include "stdafx.h"
#include "SDKDemoControl.h"


SDKDemoControl::SDKDemoControl(void)
{
	
}


SDKDemoControl::~SDKDemoControl(void)
{
}
